"""Run the code"""

__version__ = "0.1.0"

# from calculatorkzv1.calculatorkzv1 import Calculator

# if __name__ == "__main__":
#     calculator()