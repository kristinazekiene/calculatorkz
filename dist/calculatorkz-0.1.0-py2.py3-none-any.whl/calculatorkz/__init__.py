"""Run the code"""

__version__ = "0.1.0"

# from calculatorkz.calculatorkz import calculator

# if __name__ == "__main__":
#     calculator()